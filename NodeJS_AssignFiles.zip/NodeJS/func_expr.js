//function expression
function callFunc(fun){
  fun();
}
var sayHello = function(){
  console.log("Hello World");
};
callFunc(sayHello);
