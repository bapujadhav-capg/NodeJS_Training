var http = require('http');
var server = http.createServer(function(req,res){
  console.log('request was made from '+ req.url);
  res.writeHead(200,{'content-type': 'text/plain'});
  res.end('Hello Team');

});

server.listen(4000,'127.0.0.1');
console.log('Hey dud, listening to port no 4000');
