var module_pattern = require('./module_pattern');

console.log(module_pattern.counter(['Amit','Shambu','Divya','Bapu']));
console.log(module_pattern.adder(4,5));
console.log(module_pattern.adder(module_pattern.pi, 3));
