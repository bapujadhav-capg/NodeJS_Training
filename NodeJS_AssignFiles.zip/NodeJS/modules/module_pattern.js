/*
//Method 1 :
var counter = function(arr){
  return 'There are '+ arr.length + ' elements this array.';
};
var adder = function(x,y){
  return `The sum of two numbers is ${x+y}`;
};

var pi = 3.142;

module.exports.counter = counter;
module.exports.adder = adder;
module.exports.pi = pi;
*/
/*
//Method 2:
module.exports.counter = function(arr){
  return '2nd Method:There are '+ arr.length + ' elements this array.';
};
module.exports.adder = function(x,y){
  return`2nd Method:The sum of two numbers is ${x+y}`;
};
module.exports.pi = 3.142;

*/
//Method 3:
var counter = function(arr){
  return '3rd Method:There are '+ arr.length + ' elements this array.';
};
var adder = function(x,y){
  return `3rd Method:The sum of two numbers is ${x+y}`;
};

var pi = 3.142;
module.exports = {
  counter: counter,
  adder: adder,
  pi: pi
};
