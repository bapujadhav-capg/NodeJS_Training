var counter = function(arr){
  return 'There are '+ arr.length + ' elements this array.';
};
//console.log(counter(['Amit','Shambu','Divya','Bapu']));
module.exports = counter // this need for require function in another JS file or module.
