var counter = require('./count');
//console.log('There are '+ arr.length + ' elements this array. This is from require function.');

//console.log(counter(['Amit','Shambu','Divya']));
console.log(counter(['Amit','Shambu','Divya','Bapu']));
