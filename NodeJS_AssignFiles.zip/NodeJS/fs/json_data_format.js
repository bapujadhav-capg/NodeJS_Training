var http = require('http');
var fs = require('fs');

var server = http.createServer(function(req,res){
  console.log('request was made from '+ req.url);
  res.writeHead(200,{'content-type': 'application/json'});
var myObj = {
  name: 'Ramesh',
  job:'Tester',
  age:30
};
res.end(JSON.stringify(myObj));
});
server.listen(4000,'127.0.0.1');
console.log('Hey dud, listening to port no 4000');
