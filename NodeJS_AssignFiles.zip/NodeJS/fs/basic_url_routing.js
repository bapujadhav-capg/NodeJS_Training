var http = require('http');
var fs = require('fs');

var server = http.createServer(function(req,res){
  console.log('request was made from '+ req.url);
  if (req.url === '/home' || req.url === '/'){
    res.writeHead(200,{'content-type': 'text/html'});
    fs.createReadStream(__dirname + '/index.html').pipe(res);
  } else if(req.url === '/api/store') {
    var store = [{item: 'paper', rate: 10}, {item: 'pen', rate: 15}, {item: 'eraser', rate: 5}];
    res.writeHead(200,{'content-type': 'application/json'});
    res.end(JSON.stringify(store));
  } else {
      res.writeHead(404,{'content-type': 'text/html'});
      fs.createReadStream(__dirname + '/404.html').pipe(res);;
  }
});
  server.listen(4000,'127.0.0.1');
  console.log('Hey dud, listening to port no 4000');