var http = require('http');
var fs = require('fs');

var server = http.createServer(function(req,res){
  console.log('request was made from '+ req.url);
  res.writeHead(200,{'content-type': 'text/html'});
  var myReadStream = fs.createReadStream(__dirname + '/index.html','utf8');
    myReadStream.pipe(res); // piping this read strea date to html page
});

server.listen(4000,'127.0.0.1');
console.log('Hey dud, listening to port no 4000');
