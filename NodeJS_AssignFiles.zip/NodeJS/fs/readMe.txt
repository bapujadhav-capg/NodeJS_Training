This is test file for reading and writing of stream functionality in node js.
msyReadStream
asaadas
adasdas
s
vdasfds
sdv
asaadasgsdgasd

sdgv
dsfgb
sdfb
sdfbhwer
y

refNBVbnDFGNDGBvN VCBnCVBncvbbNfg
fg
hd
fgjd
fgjddfgj
g

This is end of file.
