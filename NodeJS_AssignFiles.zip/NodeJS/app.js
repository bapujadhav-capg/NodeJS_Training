setTimeout(function() {
  console.log("2 secs have passed");
},2000);
