var strftime = require('strftime');
console.log(strftime('%F %T'),new Date());