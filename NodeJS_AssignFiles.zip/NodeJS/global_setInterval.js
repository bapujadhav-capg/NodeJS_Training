var time = 0;
var timer = setInterval(function(){
time += 3;
console.log(time +" time have passed");
if (time > 10){
   clearInterval(timer);
 }
},2000)
