var express = require('express');
var app = express();

app.get('/' , function(request,response){
  response.send('this is home page');
});
app.get('/contact' , function(request,response){
  response.send('this is contact page');
});
app.listen(4000);
