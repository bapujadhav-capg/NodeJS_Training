function printOdd(i) {
    if(i % 2 !== 0) {
      console.log(i + " is a odd number");
    }else{
        console.log(i + " is an even number");
    }
    }
printOdd(7);
printOdd(25);
printOdd(34);
printOdd(104);