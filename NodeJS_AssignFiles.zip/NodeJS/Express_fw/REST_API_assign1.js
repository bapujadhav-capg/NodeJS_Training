const express = require("express");

const app = express();
var i;
const inventory = '[{"name":"Banana","quantity":3},{"name":"Mosambi","quantity":7},{"name":"Mango","quantity":55}]';
const json = JSON.parse(inventory);

app.get("/inventory", function (req, res) {
  res.send(json);
});
for(i in json) {
    name1 = json[i].name
app.get("/inventory/:name1", function (req, res) {
    for(i in json) {
        if(json[i].name == "Mango") {
            res.send(json[i]);
        }
    }
  });
}
app.listen(4000);
console.log("Listening to port 4000");