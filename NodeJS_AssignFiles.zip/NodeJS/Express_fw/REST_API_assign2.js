const express = require("express");
var { Joi } = require("joi");
const app = express();
var i;
const inventory = [
{name:'Banana', quantity:5},
{name:'Mosambi', quantity:7},
{name:'Mango', quantity:70}
];

app.put('/api/inventory/:quantity', (req, res) => {
    const invent = inventory.find(b => b.quantity === parseInt(req.params.quantity));
    if(!invent) res.status(404).send('not found');
    
    const { error } = validateInvent(req.body);
    if (error) {
        res.status(400).send(error.details[0].message);
        return;
    }

    invent.name = req.body.name;
    res.send(invent);
});

function validateInvent(invent) {
  const schema = {
    name: Joi.string().min(3).required()
  };

  return Joi.validate(invent, schema);
}

app.listen(4000);
console.log("Listening to port 4000");