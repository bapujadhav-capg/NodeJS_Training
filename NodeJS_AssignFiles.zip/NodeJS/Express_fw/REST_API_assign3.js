var express = require("express");

var app = express();
app.use(express.json());

const inventory = [
    { name:'Banana', quantity:3},
    { name:'Mosambi', quantity:7},
    { name:'Mango', quantity:55}
    ];

app.post('/inventory/add', (req, res) => {
    const invent = {
        name: 'Oranges',
        quantity: 50
     
    };
    inventory.push(invent);
    res.send(invent);
});

//const json = JSON.parse(inventory);
app.get("/inventory", function (req, res) {
    res.send(invent);
  });

app.listen(4000);
console.log("Listening to port 4000");