const PI = 3.141592653589793;
console.log(PI);
PI = 3.4
console.log(PI);
