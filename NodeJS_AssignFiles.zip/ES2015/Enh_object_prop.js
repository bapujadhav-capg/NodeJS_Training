var Order = { 
    id: 1,
    title: 'Paper',
    price: 10,
    printorder:function ()
    {``
        console.log(this.id);
        console.log(this.title);
        console.log(this.price);
    },
    getorder:function ()
    {
        console.log(this.id);
        console.log(this.price);
    }
};
Order.printorder();
Order.getorder();