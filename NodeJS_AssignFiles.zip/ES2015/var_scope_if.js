var fname = "Ramesh";
if(true) {
    console.log(fname); // Answer: "Ramesh"
    var fname = "Suresh";
}
console.log(fname); // Answer: "Suresh".Because JavaScript does not have block scope